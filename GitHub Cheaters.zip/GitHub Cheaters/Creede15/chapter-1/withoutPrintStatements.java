/*
* Rewrite the following code as a series of equivalent System.out.println statements 
* (i.e., without any System.out.print statements):
*
* System.out.print("Twas ");
* System.out.print("brillig and the ");
* System.out.println(" ");
* System.out.print("  slithy toves did");
* System.out.print(" ");
* System.out.println("gyre and");
* System.out.println(  "gimble");
* System.out.println();
* System.out.println(  "in the wabe." );
*/

System.out.println("Twas brillig and the  ");
System.out.println("  slithy toves did gyre and");
System.out.println(  "gimble");
System.out.println();
System.out.println(  "in the wabe." );


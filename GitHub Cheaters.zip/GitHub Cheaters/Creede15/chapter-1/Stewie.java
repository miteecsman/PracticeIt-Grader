/*
* Write a complete Java program in a class named Stewie that prints the following output:
* 
* //////////////////////
* || Victory is mine! ||
* \\\\\\\\\\\\\\\\\\\\\\
*/

public class Stewie{
    public static void main(String[] args){
        System.out.println("//////////////////////");
        System.out.println("|| Victory is mine! ||");
        System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
    }
}


/*
* Write a complete Java program in a class named Egg that displays the following output:
*
*   _______
*  /       \
* /         \
* -"-'-"-'-"-
* \         /
*  \_______/
*/

public class Egg{
    public static void main(String[] args){
        System.out.println("  _______");
        System.out.println(" /       \\");
        System.out.println("/         \\");
        System.out.println("-\"-'-\"-'-\"-");
        System.out.println("\\         /");
        System.out.println(" \\_______/");
    }
}


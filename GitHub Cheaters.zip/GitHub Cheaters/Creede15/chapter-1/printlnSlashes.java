/*
* Write a println statement that produces the following output: 
* / \ // \\ /// \\\
*/

System.out.print("/ \\ // \\\\ /// \\\\\\");

/*
* Write a method named lastDigit that returns the last digit of an integer. 
*/

public static int lastDigit(int num) {
   return Math.abs(num % 10); 
}

/*
* Write your own code to produce the following output:
* 2 times 1 = 2
* 2 times 2 = 4
* 2 times 3 = 6
* 2 times 4 = 8
*/

public class Count2 {
    public static void main(String[] args) {
        for (int i = 1; i <= 4; i++) {
            System.out.println("2 times " + i + " = " + 2 * i);
        }
    }
}

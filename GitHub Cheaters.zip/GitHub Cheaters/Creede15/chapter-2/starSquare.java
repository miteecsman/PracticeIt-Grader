/* Write for loops to produce the following output
*  *****
*  *****
*  *****
*  *****
*/

for (int i = 1; i <= 4; i++) {
    for (int j = 1; j <= 5; j++) {
        System.out.print("*");
    }
    System.out.println();
}

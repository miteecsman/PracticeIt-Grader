/* Write a method named area that accepts the radius of a circle as a 
 * parameter and returns the area of a circle with that radius. You may assume 
 * that the radius is non-negative.
 */
public double area(double r) {
    return Math.PI * r * r;
}

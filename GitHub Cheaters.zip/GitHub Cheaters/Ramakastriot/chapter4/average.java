/* Write a method called average that takes two integers as parameters and 
 * returns the average of the two integers.
 */
public double average(int a, int b) {
    return (a + b) / 2.0;
}
